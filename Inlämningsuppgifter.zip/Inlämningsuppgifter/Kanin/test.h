#ifndef TEST_H
#define TEST_H
#include "RabbitRace.h"

class test
{
    public:
        test();
        ~test(){}
    protected:
    private:
};

#endif // TEST_H
