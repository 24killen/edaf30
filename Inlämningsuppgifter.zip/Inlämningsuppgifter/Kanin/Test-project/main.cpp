#include <iostream>
#include "../test.h"
using namespace std;

int main(){
    test t;
    return 0;
}
