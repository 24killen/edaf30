#include "Bank.h"

using namespace std;

Bank::Bank(string fil)
{
    vector<Konto> konton;
    nastaKontonummer = 1;
    filnamn = fil;
    ifstream input;
    ofstream output;
    ladda();
}

Bank::~Bank()
{

}

// En metod som anv�nds f�r att spara all data till en fil.
void Bank::spara(){
    output.open(filnamn);
    for(int i = 0; i < antalKonton; i++){
        output<< konton.at(i).getKontonummer() << endl;
        output << konton.at(i).getKontoinnehavare() << endl;
        output<< konton.at(i).getKontotyp() << endl;
        output<< konton.at(i).getSaldo() << endl;
    }
    output.close();
}

// En metod som anv�nds f�r att ladda all data fr�n fil till hela systemet.
// Skapar konton och l�gger in dessa i vektorn konton enligt den externa filens inneh�ll.
// Anv�nder sedan �ven en annan metod f�r att best�mma n�sta tillg�ngliga kontonummer.
void Bank::ladda(){
    ifstream fileExists(filnamn);
    if(fileExists){
        input.open(filnamn);
        string text;
        string nyckelord;

        string kontoinnehavare;
        int kontonummer,saldo;
        char kontotyp;
        bool fortsatt = true;

        while(input.good()){
            getline(input,text);
            if(text != ""){
                kontonummer = atoi(text.c_str());

                getline(input,text);
                kontoinnehavare = text;

                getline(input,text);
                kontotyp = text.c_str()[0];

                getline(input,text);
                saldo = atoi(text.c_str());

                Konto k(kontoinnehavare,kontonummer,kontotyp);
                k.sattIn(saldo);
                antalKonton++;

                konton.push_back(k);
            }else{
                fortsatt = false;
            }

        }
        input.close();
        fileExists.close();
    }
    nastaKontonummer = hamtaStorstaKontonummer();
}

int Bank::hamtaStorstaKontonummer(){
 int tmp = nastaKontonummer;
 int highestNumber = tmp;
    for(int i = 0; i < antalKonton; i++){
        tmp = konton.at(i).getKontonummer()+1;
        if(tmp > highestNumber){
            highestNumber = tmp;
        }
    }
    return highestNumber;
}

// Publik metod som hanterar inmatning och skapar
// sedan ett nytt konto samt sparar undan detta i en vektor.
void Bank::skapaKonto(){
    string kontoinnehavare;
    char kontotyp;
    bool korrekt = false;

    cout << "Skapande av nytt konto. Skriv in namn och kontotyp." << endl;

    cout << "Kontoinnehavare: ";
    cin.ignore();
    getline(cin,kontoinnehavare);

    while(!korrekt){
        printTillgangligaTyper();

        cout << "Kontotyp: ";
        cin >> kontotyp;
        kontotyp = toupper(kontotyp);

        if(kontotyp == 'S' || kontotyp == 'T' ){
            korrekt = true;
            cin.sync();
        }else{
            cout << "Kontotyp " << kontotyp << " finns inte. Forsok igen." << endl;
            cout << "----------------------------------------------------" << endl;
            cin.sync();
        }
    }
    skapaKonto(kontoinnehavare, kontotyp);
}

// Privat metod som anv�nds av den publika metoden med samma namn.
// Metoden skapar ett nytt konto med den korrekta inmatningen och
// sparar detta i den statiska vektorn "konton".
void Bank::skapaKonto(string kontoinnehavare, char kontotyp){
    Konto k(kontoinnehavare, nastaKontonummer++, kontotyp);
    konton.push_back(k);
    antalKonton++;
    spara();
    cout << "Kontot skapades med kontonummer " << (nastaKontonummer-1) << "." << endl;
}

// Publik metod som anv�nds f�r att l�gga till ett belopp p� ett visst konto.
// Metoden anv�nder tv� privata hj�lpmetoder f�r att hantera inmatningen av
// kontonummer och belopp. (kontonummerInput() och beloppInput())
void Bank::sattIn(){
    int kontonummer = kontonummerInput();
    if(kontonummer != 0){
        int belopp = beloppInput();
        while(belopp<0){
            cout << "Du kan inte satta in mindre an 0 kr pa ditt konto. Forsok igen." << endl;
            belopp = beloppInput();
        }
        sattIn(kontonummer, belopp);
    }
}

// Privat metod som s�tter in det korrekta belopped till det korrekta kontot.
void Bank::sattIn(int kontonummer, int belopp){
    int index = hamtaKontoIndex(kontonummer);
    konton.at(index).sattIn(belopp);
    spara();
}

// Hanterar inmatningen f�r att ta ut en specifik
// summa pengar fr�n ett specifikt konto.
void Bank::taUt(){
    int kontonummer = kontonummerInput();
    if(kontonummer != 0){
        int belopp = beloppInput();
        while(belopp<0){
            cout << "Du kan inte ta ut mindre an 0 kr pa ditt konto. Forsok igen." << endl;
            belopp = beloppInput();
        }
        taUt(kontonummer, belopp);
    }
}

// Tar ut en specifik summa pengar fr�n ett specifikt konto
void Bank::taUt(int kontonummer, int belopp){
    int index = hamtaKontoIndex(kontonummer);
    konton.at(index).taUt(belopp);
    spara();
}

// Hanterar inmatning f�r att h�mta saldot f�r ett specifikt konto.
void Bank::saldo(){
    int kontonummer = kontonummerInput();
    if(kontonummer != 0){
        saldo(kontonummer);
    }
}

// Skriver ut saldot f�r ett specifikt konto.
void Bank::saldo(int kontonummer){
    int index = hamtaKontoIndex(kontonummer);
    int saldo = konton.at(index).getSaldo();
    cout << "Saldot for kontonummer " << kontonummer << " ar: " << saldo << endl;
}

// Skriver ut all information om alla konton som finns i systemet.
void Bank::printInfoFranAlla(){
    cout << "Information fran alla konton: " << endl;
    cout << "__________________________________________" << endl;
    for(int i = 0; i < antalKonton; i++){
        printInfo(i);
    }
}

// Hanterar inmatningen f�r att skriva ut vilka konton som �gs av samma kontoinnehavare.
void Bank::printInfoFranAllaMedNamn(){
    string namn;
    cout << "Namn: ";
    cin.ignore();
    getline(cin,namn);
    printInfoFranAllaMedNamn(namn);
}

// Skriver ut information p� alla konton som �gs av samma kontoinnehavare.
void Bank::printInfoFranAllaMedNamn(string namn){
    int antalKontonForNamn = 0;
    for(int i = 0; i < antalKonton; i++){
        if(compareStringsIgnoreCase(namn, konton.at(i).getKontoinnehavare())){
            if(antalKontonForNamn == 0){
                cout << "Alla konton for " << namn << ":"<<endl;
                cout << "__________________________________________" << endl;
            }
            printInfo(i);
            antalKontonForNamn++;
        }
    }
}

// Hanterar inmatning och bekr�ftelse f�r att ta bort ett konto.
void Bank::taBort(){
    int kontonummer = kontonummerInput();
    char bekrafta;
    char dummy;
    bool korrekt = false;
    while(!korrekt && kontonummer != 0){
        cout << "Ar du saker pa att du vill ta bort detta konto? (Y/n)";
        if(cin >> bekrafta){
            if(toupper(bekrafta) == 'Y' || toupper(bekrafta) == 'N'){
                korrekt = true;
                cin.sync();
                if(toupper(bekrafta) == 'Y'){
                    taBort(kontonummer);
                }else{
                    cout << "Avstangning avbruten, ingenting ar andrat." << endl;
                }
            }else{
                cout << "Felaktig inmatning for bekraftande. Forsok igen" << endl;
                cin.sync();
            }
        }else{
            cin.clear();
            cin >> dummy;
        }
    }
}

// Tar bort ett specifikt konto fr�n vektorn konton.
void Bank::taBort(int kontonummer){
    int index = hamtaKontoIndex(kontonummer);
    konton.erase(konton.begin()+index);
    antalKonton--;
    spara();
    cout << "Kontot med kontonummer " << kontonummer << " ar nu avslutat (borttaget)." << endl;
}

// Visar en meny och hanterar inmatning f�r denna.
// Startar olika funktioner beroende p� menyval.
void Bank::modifiera(){
    int kontonummer = kontonummerInput();
    bool korrekt = false;
    int val;
    string dummy;
    while(!korrekt && kontonummer != 0){
        cout << "----- Modifiera konto -----" << endl;
        cout << "1. Kontoinnehavare" << endl;
        cout << "2. Kontotyp" << endl;
        cout << "0. Aterga till huvudmenyn" << endl;
        if(cin >> val){
            switch(val){
            case 0:
                korrekt = true;
                cout << "Atergar till huvudmenyn." << endl;
                break;
            case 1:
                modifieraKontoinnehavare(kontonummer);
                break;
            case 2:
                modifieraKontotyp(kontonummer);
                break;
            default:
                cout << "Fel, det fanns inget alternativ som matchar ditt val. (" << val << ")"  << endl;
                cout << "Atergar till huvudmenyn." << endl;
                break;
            }
        }else{
            cin.clear();
            cin >> dummy;
            val = -1;
            cout << "Felaktig inmatning vid val av modifiering. Forsok igen" << endl;
        }
    }
}

// En metod f�r att kontrollera och hantera �ndringar av kontoinnehavaren f�r ett specifikt konto.
void Bank::modifieraKontoinnehavare(int kontonummer){
    string namn;
    int index = hamtaKontoIndex(kontonummer);
    if(kontonummer != 0){
        cout << "Nytt namn: ";
        cin.ignore();
        getline(cin,namn);
        konton.at(index).setKontoinnehavare(namn);
        spara();
    }
}

// En metod f�r att kontrollera och hantera �ndringar av kontotypen f�r ett specifikt konto.
void Bank::modifieraKontotyp(int kontonummer){
    bool korrekt = false;
    char typ, dummy;
    int index = hamtaKontoIndex(kontonummer);
    while(!korrekt && kontonummer != 0){
        printTillgangligaTyper();
        cout << "Kontotyp: ";
        if(cin >> typ){
            typ = toupper(typ);
            if(typ == 'S' || typ == 'T' ){
                korrekt = true;
                konton.at(index).setKontotyp(typ);
                cin.sync();
                spara();
            }else{
                cout << "Kontotyp " << typ << " finns inte. Forsok igen." << endl;
                cout << "----------------------------------------------------" << endl;
                cin.sync();
            }
        }else{
            cin.clear();
            cin >> dummy;
            typ = ' ';
            cout << "Felaktig inmatning for andring av kontotyp, forsok igen." << endl;
        }
    }
}

// Skriver ut informationen f�r ett konto med index "i" fr�n vektorn "konton".
void Bank::printInfo(int i){
    cout << "Kontoinnehavare: " << konton.at(i).getKontoinnehavare() << endl;
    cout << "Kontonummer: " << konton.at(i).getKontonummer() << endl;
    cout << "Kontotyp: " << konton.at(i).getKontotyp() << endl;
    cout << "Saldo: " << konton.at(i).getSaldo() << endl;
    cout << "__________________________________________" << endl;
}

// Hanterar inmatningen av kontonummer och
// kontrollerar att kontonumret finns.
// Returnerar det korrekt inmatade kontonumret
// eller 0 om anv�ndaren v�ljer att avbryta.
int Bank::kontonummerInput(){
    int kontonummer;
    bool korrekt = false;
    string dummy;
    cout << "Skriv in ditt kontonummer, avbryt med 0" << endl;
    while(!korrekt){
        cout << "Kontonummer: ";
        if(cin >> kontonummer){
            if(kontonummer == 0){
                return kontonummer;
            }
            if(finnsKontot(kontonummer)){
                korrekt = true;
            }else{
                cout << "Kontonummer " << kontonummer << " finns inte. Forsok igen." << endl;
            }
        }else{
            cin.clear();
            cin >> dummy;
            cout << "Felaktig inmatning for kontonummer, forsok igen." << endl;
            kontonummer = -1;
        }
    }
    return kontonummer;
}

// Hanterar inmatningen av belopp-v�rdet.
// Returnerar belopp-v�rdet.
int Bank::beloppInput(){
    int belopp;
    bool korrekt = false;
    string dummy;
    while(!korrekt){
        cout << "Belopp: ";
        if(cin >> belopp){
            korrekt = true;
        }else{
            cin.clear();
            cin >> dummy;
            cout << "Felaktig inmatning for belopp, forsok igen." << endl;
            belopp = -1;
        }
    }
    return belopp;
}

// Letar upp p� vilket index i vektorn koton d�r ett specifikt kontonummer finns.
// Om kontonumret inte finns s� returneras -1
// Annars returneras index f�r det kontonumret.
int Bank::hamtaKontoIndex(int kontonummer){
    for(int i = 0; i < antalKonton; i++){
        if(kontonummer == konton.at(i).getKontonummer()){
            return i;
        }
    }
    return -1;
}

// Kontrollerar om ett inmatat kontonummer finns.
// Returnerar true om det finns, och false om det inte finns.
bool Bank::finnsKontot(int kontonummer){
    if(hamtaKontoIndex(kontonummer) != -1){
        return true;
    }
    return false;
}

// Compares two strings (non case sensitive) and returns true if
// they are equal. Or false if they don't match.
// This method is inspired by PiotrNycz on stackoverflow.
// Source: http://stackoverflow.com/a/12568507
bool Bank::compareStringsIgnoreCase(string str1, string str2){
    if(str1.length() == str2.length()){
        for(int i=0; i<str1.length(); i++){
            if(toupper(str1[i]) != toupper(str2[i])){
                return false;
            }
        }
        return true;
    }
    return false;
}

// En enkel hj�lpmetod f�r att skriva ut tillg�ngliga kontotyper.
void Bank::printTillgangligaTyper(){
        cout << endl;
        cout << "Tillgangliga typer:" << endl;
        cout << "S - Sparkonto" << endl;
        cout << "T - Transaktionskonto" << endl << endl;
}
