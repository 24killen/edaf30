#include <iostream>
#include <random>
#include <ctime>
#include "Konto.h"
#include "Bank.h"

using namespace std;

// Prints the menu
void printMenu(){
    cout << "---------------MENY---------------" << endl;
    cout << "1. Skapa konto" << endl;
    cout << "2. Insattning av belopp till konto" << endl;
    cout << "3. Uttag av belopp fran konto" << endl;
    cout << "4. Fraga om saldo for konto" << endl;
    cout << "5. Lista information for alla konton" << endl;
    cout << "6. Lista information for alla konton for en viss kontoinnehavare" << endl;
    cout << "7. Avsluta (ta bort) ett existerande konto" << endl;
    cout << "8. Modifiera ett existerande konto" << endl;
    cout << "0. Avsluta programmet" << endl;
}



int main()
{
    string filnamn = "Banksystem.txt";
    Bank b(filnamn);

    int val = -1;
    string dummy;
    while(val!=0){
        printMenu();
        if(cin >> val){ // If the input is an int
            switch(val){
                case 0: // Avsluta programmet
                    break;
                case 1: // Skapa konto
                    b.skapaKonto();
                    break;
                case 2: // Insattning av belopp till konto
                    b.sattIn();
                    break;
                case 3: // Uttag av belopp fran konto
                    b.taUt();
                    break;
                case 4: // Fraga om saldo for konto
                    b.saldo();
                    break;
                case 5: // Lista information for alla konton
                    b.printInfoFranAlla();
                    break;
                case 6: // Lista information for alla konton for en viss kontoinnehavare
                    b.printInfoFranAllaMedNamn();
                    break;
                case 7: // Avsluta (ta bort) ett existerande konto
                    b.taBort();
                    break;
                case 8: // Modifiera ett existerande konto
                    b.modifiera();
                    break;
                default:// �vriga v�rden
                    cout << "Menyval " << val << " finns inte i menyn, forsok igen." << endl;
                    break;
            }
        }
        else{ // Vid annan inmatning �n en int.
            cin.clear();    // Nollst�ll cin
            cin >> dummy;   // L�gg in en dummy
            val = -1;       // S�tter menyvalet till initieringsv�rdet
            cout << "Inkorrekt inmatning, forsok igen!" << endl;    // Skriver ut felmeddelande
        }
    }

    return 0;
}
